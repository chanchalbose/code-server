import { IKeyValueStorage } from 'tas-client';
import * as vscode from 'vscode';
export declare class MementoKeyValueStorage implements IKeyValueStorage {
    private mementoGlobalStorage;
    constructor(mementoGlobalStorage: vscode.Memento);
    getValue<T>(key: string, defaultValue?: T | undefined): Promise<T | undefined>;
    setValue<T>(key: string, value: T): void;
}
