"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const VSCodeFilterProvider_1 = require("../vscode-tas-client/VSCodeFilterProvider");
const assert = require("assert");
suite('General Tests', () => {
    test('Should provide default filters for tas client', async () => {
        const filterProvider = new VSCodeFilterProvider_1.VSCodeFilterProvider('extension_name', 'extension_version', VSCodeFilterProvider_1.TargetPopulation.Internal);
        const filters = filterProvider.getFilters();
        const greaterThanZero = filters.size > 0;
        assert.equal(greaterThanZero, true);
    });
});
//# sourceMappingURL=general.test.js.map