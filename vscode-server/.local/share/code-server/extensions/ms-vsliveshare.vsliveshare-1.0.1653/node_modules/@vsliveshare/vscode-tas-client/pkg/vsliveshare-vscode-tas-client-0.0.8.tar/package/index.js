"use strict";
//
//  Copyright (c) Microsoft Corporation. All rights reserved.
//
Object.defineProperty(exports, "__esModule", { value: true });
var VSCodeTasClient_1 = require("./vscode-tas-client/VSCodeTasClient");
exports.getExperimentationService = VSCodeTasClient_1.getExperimentationService;
var VSCodeFilterProvider_1 = require("./vscode-tas-client/VSCodeFilterProvider");
exports.TargetPopulation = VSCodeFilterProvider_1.TargetPopulation;
//# sourceMappingURL=index.js.map