import { IExperimentationFilterProvider } from 'tas-client';
/**
 * Here is where we are going to define the filters we will set.
 */
export declare class VSCodeFilterProvider implements IExperimentationFilterProvider {
    private extensionName;
    private extensionVersion;
    private targetPopulation;
    constructor(extensionName: string, extensionVersion: string, targetPopulation: TargetPopulation);
    getFilterValue(filter: string): string | null;
    getFilters(): Map<string, any>;
}
export declare enum Filters {
    /**
     * The market in which the extension is distributed.
     */
    Market = "X-MSEdge-Market",
    /**
     * The corporation network.
     */
    CorpNet = "X-FD-Corpnet",
    /**
     * Version of the application which uses experimentation service.
     */
    ApplicationVersion = "X-VSCode-AppVersion",
    /**
     * Insiders vs Stable.
     */
    Build = "X-VSCode-Build",
    /**
     * Client Id which is used as primary unit for the experimentation.
     */
    ClientId = "X-MSEdge-ClientId",
    /**
     * Extension header.
     */
    ExtensionName = "X-VSCode-ExtensionName",
    /**
     * The version of the extension.
     */
    ExtensionVersion = "X-VSCode-ExtensionVersion",
    /**
     * The target population.
     * This is used to separate internal, early preview, GA, etc.
     */
    TargetPopulation = "X-VSCode-TargetPopulation"
}
/**
 * Specifies the target population for the experimentation filter.
 */
export declare enum TargetPopulation {
    Team = "team",
    Internal = "internal",
    Insiders = "insiders",
    Public = "public"
}
