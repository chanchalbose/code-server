"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const VSCodeFilterProvider_1 = require("./VSCodeFilterProvider");
const tas_client_1 = require("tas-client");
const MementoKeyValueStorage_1 = require("./MementoKeyValueStorage");
const endpoint = 'https://default.exp-tas.com/vscode/ab';
const telemetryEventName = 'query-expfeature';
const telemetryPropertyName = 'VSCode.ABExp.Features';
const storageKey = 'VSCode.ABExp.Features';
const refetchInterval = 1000 * 60 * 30; // By default it's set up to 30 minutes.
/**
 *
 * @param extensionName The name of the extension.
 * @param extensionVersion The version of the extension.
 * @param telemetry Telemetry implementation.
 * @param targetPopulation An enum containing the target population ('team', 'internal', 'insiders', 'public').
 * @param memento The memento state to be used for cache.
 * @param filterProviders The filter providers.
 */
function getExperimentationService(extensionName, extensionVersion, targetPopulation, telemetry, memento, ...filterProviders) {
    if (!memento) {
        throw new Error('Memento storage was not provided.');
    }
    const extensionFilterProvider = new VSCodeFilterProvider_1.VSCodeFilterProvider(extensionName, extensionVersion, targetPopulation);
    const providerList = [extensionFilterProvider, ...filterProviders];
    const keyValueStorage = new MementoKeyValueStorage_1.MementoKeyValueStorage(memento);
    return new tas_client_1.ExperimentationService({
        filterProviders: providerList,
        telemetry: telemetry,
        storageKey: storageKey,
        keyValueStorage: keyValueStorage,
        telemetryPropertyName: telemetryPropertyName,
        telemetryEventName: telemetryEventName,
        endpoint: endpoint,
        refetchInterval: refetchInterval,
    });
}
exports.getExperimentationService = getExperimentationService;
//# sourceMappingURL=VSCodeTasClient.js.map