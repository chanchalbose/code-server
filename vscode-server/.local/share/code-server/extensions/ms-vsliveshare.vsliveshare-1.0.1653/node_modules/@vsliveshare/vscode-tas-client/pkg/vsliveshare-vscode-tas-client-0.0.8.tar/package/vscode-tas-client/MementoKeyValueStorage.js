"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class MementoKeyValueStorage {
    constructor(mementoGlobalStorage) {
        this.mementoGlobalStorage = mementoGlobalStorage;
    }
    async getValue(key, defaultValue) {
        const value = await this.mementoGlobalStorage.get(key);
        return value || defaultValue;
    }
    setValue(key, value) {
        this.mementoGlobalStorage.update(key, value);
    }
}
exports.MementoKeyValueStorage = MementoKeyValueStorage;
//# sourceMappingURL=MementoKeyValueStorage.js.map