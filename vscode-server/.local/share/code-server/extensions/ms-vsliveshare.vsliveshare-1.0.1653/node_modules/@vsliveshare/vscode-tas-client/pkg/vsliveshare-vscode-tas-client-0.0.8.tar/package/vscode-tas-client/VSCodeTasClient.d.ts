import { IExperimentationService, IExperimentationTelemetry, IExperimentationFilterProvider } from 'tas-client';
import * as vscode from 'vscode';
import { TargetPopulation } from './VSCodeFilterProvider';
/**
 *
 * @param extensionName The name of the extension.
 * @param extensionVersion The version of the extension.
 * @param telemetry Telemetry implementation.
 * @param targetPopulation An enum containing the target population ('team', 'internal', 'insiders', 'public').
 * @param memento The memento state to be used for cache.
 * @param filterProviders The filter providers.
 */
export declare function getExperimentationService(extensionName: string, extensionVersion: string, targetPopulation: TargetPopulation, telemetry: IExperimentationTelemetry, memento: vscode.Memento, ...filterProviders: IExperimentationFilterProvider[]): IExperimentationService;
